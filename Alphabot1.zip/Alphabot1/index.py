import time
from AlphaBot import AlphaBot

AB = AlphaBot()

AB.backward()
time.sleep(3)
AB.stop()

AB.left()
time.sleep(3)
AB.stop()

AB.backward()
time.sleep(3)
AB.stop()

AB.right()
time.sleep(3)
AB.stop()