import RPi.GPIO as GPIO   # Libreria per controllare i pin GPIO del Raspberry Pi
import time               # Libreria per gestire il tempo (ritardi, ecc.)

# chi ha montato l'alphabot è scemo e lo ha montato con i motori al contrario

class AlphaBot(object):
	
	def __init__(self,in1=12,in2=13,ena=6,in3=20,in4=21,enb=26, dl=19, dr=16):
		# Pin di controllo motori (numerazione BCM dei pin GPIO)
		self.IN1 = in3   # Direzione motore A (pin 1)
		self.IN2 = in4   # Direzione motore A (pin 2)
		self.IN3 = in1   # Direzione motore B (pin 1)
		self.IN4 = in2   # Direzione motore B (pin 2)
		self.ENA = ena   # Pin di abilitazione (PWM) motore A
		self.ENB = enb   # Pin di abilitazione (PWM) motore B

		# per i sensori
		self.DL = dl
		self.DR = dr

		# Configurazione dei GPIO
		GPIO.setmode(GPIO.BCM)        # Usa la numerazione BCM
		GPIO.setwarnings(False)       # Disabilita i warning
		GPIO.setup(self.IN1,GPIO.OUT) # Configura i pin come output
		GPIO.setup(self.IN2,GPIO.OUT)
		GPIO.setup(self.IN3,GPIO.OUT)
		GPIO.setup(self.IN4,GPIO.OUT)
		GPIO.setup(self.ENA,GPIO.OUT)
		GPIO.setup(self.ENB,GPIO.OUT)

		# per i sensori
		GPIO.setup(self.DL,GPIO.IN, GPIO.PUD_UP)
		GPIO.setup(self.DR,GPIO.IN, GPIO.PUD_UP)


		self.forward()                # Imposta la direzione iniziale su "avanti"

		# Configura PWM sui pin di enable (ENA/ENB) con frequenza 500Hz
		self.PWMA = GPIO.PWM(self.ENA,500)
		self.PWMB = GPIO.PWM(self.ENB,500)

		# Avvia i PWM con duty cycle iniziale al 50% (velocità media)
		self.PWMA.start(50)
		self.PWMB.start(50)

	# --------- METODI DI MOVIMENTO ---------

	def forward(self):
		# Entrambi i motori girano in avanti
		GPIO.output(self.IN1,GPIO.HIGH)
		GPIO.output(self.IN2,GPIO.LOW)
		GPIO.output(self.IN3,GPIO.LOW)
		GPIO.output(self.IN4,GPIO.HIGH)

	def stop(self):
		# Ferma entrambi i motori
		GPIO.output(self.IN1,GPIO.LOW)
		GPIO.output(self.IN2,GPIO.LOW)
		GPIO.output(self.IN3,GPIO.LOW)
		GPIO.output(self.IN4,GPIO.LOW)

	def backward(self):
		# Entrambi i motori girano indietro
		GPIO.output(self.IN1,GPIO.LOW)
		GPIO.output(self.IN2,GPIO.HIGH)
		GPIO.output(self.IN3,GPIO.HIGH)
		GPIO.output(self.IN4,GPIO.LOW)

	def left(self):
		# Ruota a sinistra (solo un motore attivo)
		GPIO.output(self.IN1,GPIO.HIGH)
		GPIO.output(self.IN2,GPIO.LOW)
		GPIO.output(self.IN3,GPIO.LOW)
		GPIO.output(self.IN4,GPIO.LOW)

	def right(self):
		# Ruota a destra (solo un motore attivo)
		GPIO.output(self.IN1,GPIO.LOW)
		GPIO.output(self.IN2,GPIO.LOW)
		GPIO.output(self.IN3,GPIO.LOW)
		GPIO.output(self.IN4,GPIO.HIGH)
		
	# --------- METODI PER VELOCITÀ ---------

	def setPWMA(self,value):
		# Imposta velocità del motore A (0-100%)
		self.PWMA.ChangeDutyCycle(value)

	def setPWMB(self,value):
		# Imposta velocità del motore B (0-100%)
		self.PWMB.ChangeDutyCycle(value)	
		
	# --------- CONTROLLO PERSONALIZZATO ---------
	def setMotor(self, left, right):
		# Controlla indipendentemente i due motori
		# right: positivo = avanti, negativo = indietro
		if((right >= 0) and (right <= 100)):
			GPIO.output(self.IN1,GPIO.HIGH)
			GPIO.output(self.IN2,GPIO.LOW)
			self.PWMA.ChangeDutyCycle(right)
		elif((right < 0) and (right >= -100)):
			GPIO.output(self.IN1,GPIO.LOW)
			GPIO.output(self.IN2,GPIO.HIGH)
			self.PWMA.ChangeDutyCycle(0 - right)

		# left: positivo = avanti, negativo = indietro
		if((left >= 0) and (left <= 100)):
			GPIO.output(self.IN3,GPIO.HIGH)
			GPIO.output(self.IN4,GPIO.LOW)
			self.PWMB.ChangeDutyCycle(left)
		elif((left < 0) and (left >= -100)):
			GPIO.output(self.IN3,GPIO.LOW)
			GPIO.output(self.IN4,GPIO.HIGH)
			self.PWMB.ChangeDutyCycle(0 - left)

	# per i sensori

	def sesoreDestro(self):

		return GPIO.input(self.DR) == 0

	def sesoreSinistro(self):
	
			return GPIO.input(self.DL) == 0
