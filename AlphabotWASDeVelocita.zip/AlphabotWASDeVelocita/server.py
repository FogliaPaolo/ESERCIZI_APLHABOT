import socket
from AlphaBot import AlphaBot
import time

ADDRESS = ('0.0.0.0', 8080)
MAX_CONNECTIONS = 3
BUFFER = 4096

comandoPrecedente = 'stop'
velocitaRobot = 50

ab = AlphaBot()
ab.stop()  # OBBLIGATORIO

# creo un socket TCP
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(ADDRESS)
s.listen(MAX_CONNECTIONS)
connection, sender_address = s.accept()

while True:
    message_bin = connection.recv(BUFFER)
    if not message_bin:
        break

    comando = message_bin.decode().strip()

    if comando == "velocita+" and velocitaRobot != 100:
        velocitaRobot = velocitaRobot + 10
        print(f"VELOCITA = {velocitaRobot}")
        ab.setPWMA(velocitaRobot)
        ab.setPWMB(velocitaRobot)
    elif comando == "velocita-" and velocitaRobot != 0:
        velocitaRobot = velocitaRobot - 10
        print(f"VELOCITA = {velocitaRobot}")
        ab.setPWMA(velocitaRobot)
        ab.setPWMB(velocitaRobot)
        


    print(f"comandoPrecedente = {comandoPrecedente}")
    print(f"messaggio ricevuto da client = {comando}")

    if comando == comandoPrecedente:
        continue

    comandoPrecedente = comando

    if comando == "avanti":
        ab.forward()
    elif comando == "indietro":
        ab.backward()
    elif comando == "destra":
        ab.right()
    elif comando == "sinistra":
        ab.left()
    elif comando == "stop":
        ab.stop()
    # elif comando == "velocita+":
    #     velocitaRobot = velocitaRobot + 10
    #     print(f"VELOCITA = {velocitaRobot}")
    #     ab.setPWMA(velocitaRobot)
    #     ab.setPWMB(velocitaRobot)
    # elif comando == "velocita-":
    #     velocitaRobot = velocitaRobot - 10
    #     print(f"VELOCITA = {velocitaRobot}")
    #     ab.setPWMA(velocitaRobot)
    #     ab.setPWMB(velocitaRobot)
  

connection.close()
s.close()
