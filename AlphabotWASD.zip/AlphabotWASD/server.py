import socket
from AlphaBot import AlphaBot
import time

ADDRESS = ('0.0.0.0', 8080)
MAX_CONNECTIONS = 3
BUFFER = 4096

comandoPrecedente = 'stop'

ab = AlphaBot()
ab.stop()  # OBBLIGATORIO

# creo un socket TCP
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(ADDRESS)
s.listen(MAX_CONNECTIONS)
connection, sender_address = s.accept()

while True:
    message_bin = connection.recv(BUFFER)
    if not message_bin:
        break

    comando = message_bin.decode().strip()
    print(f"comandoPrecedente = {comandoPrecedente}")
    print(f"messaggio ricevuto da client = {comando}")

    if comando == comandoPrecedente:
        continue

    comandoPrecedente = comando

    if comando == "avanti":
        ab.forward()
    elif comando == "indietro":
        ab.backward()
    elif comando == "destra":
        ab.right()
    elif comando == "sinistra":
        ab.left()
    elif comando == "stop":
        ab.stop()

connection.close()
s.close()

